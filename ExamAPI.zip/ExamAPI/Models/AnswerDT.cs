﻿namespace ExamAPI.Models
{
    public class AnswerDT
    {
        public int QuestionId { get; set; }
        public string Answer { get; set; }
    }
}
