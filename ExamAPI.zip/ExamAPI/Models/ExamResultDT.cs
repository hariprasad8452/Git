﻿namespace ExamAPI.Models
{
    public class ExamResultDT
    {
        public int ExamId { get; set; }
        public string ExamName { get; set; }
        public int ObtainedMarks { get; set; }
        public int TotalMarks { get; set; }
    }
}
