﻿using ExamAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ExamAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginFunctionController : ControllerBase
    {
        ExamDBContext db = null;
        public LoginFunctionController(ExamDBContext context)
        {
            db = context;
        }
        [Route("SelectChoice")]
        [HttpPost]
        public IActionResult SelectChoice(string Name,int Level)
        {
            var id = (from c in db.Choices where c.ChoiceName==Name && c.Level==Level select c.ChoiceId).FirstOrDefault();
            return Ok(id);
        }
        [Route("SelectExam")]
        [HttpGet]
        public IActionResult GetExam(int id)
        {
            var id1 = (from e in db.Exams where e.ChoiceId == id select e.ExamId).FirstOrDefault();
            return Ok(id1);
        }
        [Route("GetQuestions")]
        [HttpGet]
        public IActionResult GetQuestions(int id)
        {
            Question Q = (from q in db.Questions where q.ExamId == id select q).FirstOrDefault();
            return Ok(Q);
        }

    }
}
