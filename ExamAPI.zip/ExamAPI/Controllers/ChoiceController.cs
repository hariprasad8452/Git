﻿using ExamAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ExamAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChoiceController : ControllerBase
    {
        ExamDBContext db = null;
        public ChoiceController(ExamDBContext context)
        {
            db = context;
        }
        [Route("GetByID")]
        [HttpGet]
        public ActionResult<IEnumerable<Choice>> GetChoices()
        {
            var choices = db.Choices.ToList();
            return Ok(choices);
        }
        [Route("Add")]
        [HttpPost]
        public ActionResult<Choice> CreateChoice(Choice choice)
        {
            db.Choices.Add(choice);
            db.SaveChanges();
            return CreatedAtAction(nameof(GetChoiceById), new { id = choice.ChoiceId }, choice);
        }
        [Route("GetID")]
        [HttpGet]
        public ActionResult<Choice> GetChoiceById(int id)
        {
            var choice = db.Choices.FirstOrDefault(c => c.ChoiceId == id);
            if (choice == null)
            {
                return NotFound();
            }
            return Ok(choice);
        }
        [Route("Update")]
        [HttpPut]
        public IActionResult UpdateChoice(int id, Choice choice)
        {
            if (id != choice.ChoiceId)
            {
                return BadRequest();
            }
            db.Entry(choice).State = EntityState.Modified;
            db.SaveChanges();
            return NoContent();
        }
        [Route("Delete")]
        [HttpDelete]
        public IActionResult DeleteChoice(int id)
        {
            var choice = db.Choices.FirstOrDefault(c => c.ChoiceId == id);
            if (choice == null)
            {
                return NotFound();
            }
            db.Choices.Remove(choice);
            db.SaveChanges();
            return NoContent();
        }
    }
}
