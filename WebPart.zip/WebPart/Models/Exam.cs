﻿using System.ComponentModel.DataAnnotations;

namespace WebPart.Models
{
    public class Exam
    {
        [Key]
        public int ExamId { get; set; }
        public string ExamName { get; set; }
        public DateTime ExamDate { get; set; }
        //public TimeSpan ExamDuration { get; set; }
        public int ExamMarks { get; set; }
        public int ChoiceId { get; set; }
        public virtual Choice Choice { get; set; }
        public ICollection<Question> questions { get; set; }
    }
}
