﻿using System.ComponentModel.DataAnnotations;

namespace WebPart.Models
{
    public class Choice
    {
        [Key]
        public int ChoiceId { get; set; }
        public string ChoiceName { get; set; }
        public int Level { get; set; }
    }
}
