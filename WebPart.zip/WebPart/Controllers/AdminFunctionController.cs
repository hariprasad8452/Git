﻿using ExamAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;

namespace WebPart.Controllers
{
    public class AdminFunctionController : Controller
    {
        Uri basedaddress = new Uri("http://localhost:9748/api");
        private readonly HttpClient _httpClient;
        public AdminFunctionController()
        {
            _httpClient = new HttpClient();
            _httpClient.BaseAddress = basedaddress;
        }
        public IActionResult Index()
        {
            //List<User> userList = new List<User>();
            //HttpResponseMessage response = _httpClient.GetAsync(_httpClient.BaseAddress + "/AdminFunction/ViewUsers").Result;
            //if (response.IsSuccessStatusCode)
            //{
            //    string data = response.Content.ReadAsStringAsync().Result;
            //    userList = JsonConvert.DeserializeObject<List<User>>(data);
            //}
            //return View(userList);
            return View();
        }
        public IActionResult AddQuestion()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> AddQuestion(Question question)
        {
            try
            {
                    using (var httpClient = new HttpClient())
                    {
                        StringContent content = new StringContent(JsonConvert.SerializeObject(question), Encoding.UTF8, "application/json");
                        using (var response
                        = await httpClient.PostAsync("http://localhost:9748/api/AdminFunction/AddQuestion", content))
                        {
                            ViewData["Message"] = "You have successfully Added Question...";
                        }
                }
                return View("Index");
            }
            catch (Exception ex)
            {
                return RedirectToAction("Error");
            }
        }
        public IActionResult UpdateQuestion()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> UpdateQuestion(Question question)
        {
            try
            {
                using (var httpClient = new HttpClient())
                {
                    StringContent content = new StringContent(JsonConvert.SerializeObject(question), Encoding.UTF8, "application/json");
                    using (var response
                    = await httpClient.PostAsync("http://localhost:9748/api/AdminFunction/UpdateQuestion", content))
                    {
                        ViewData["Message"] = "successfully Upadted Question...";
                    }
                }
                return View("Index");
            }
            catch (Exception ex)
            {
                return RedirectToAction("Error");
            }
        }
        public IActionResult ViewQuestion()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> ViewQuestion(Question question)
        {
            try
            {
                using (var httpClient = new HttpClient())
                {
                    StringContent content = new StringContent(JsonConvert.SerializeObject(question), Encoding.UTF8, "application/json");
                    using (var response
                    = await httpClient.PostAsync("http://localhost:9748/api/AdminFunction/ViewQuestion", content))
                    {
                        ViewData["Message"] = "successfully Upadted Question...";
                    }
                }
                return View("Index");
            }
            catch (Exception ex)
            {
                return RedirectToAction("Error");
            }
        }
        public IActionResult DeleteQuestion()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> DeleteQuestion(Question question)
        {
            try
            {
                using (var httpClient = new HttpClient())
                {
                    StringContent content = new StringContent(JsonConvert.SerializeObject(question), Encoding.UTF8, "application/json");
                    using (var response
                    = await httpClient.PostAsync("http://localhost:9748/api/AdminFunction/DelteQuestion", content))
                    {
                        ViewData["Message"] = "successfully Upadted Question...";
                    }
                }
                return View("Index");
            }
            catch (Exception ex)
            {
                return RedirectToAction("Error");
            }
        }

    }
}
