﻿using ExamAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace WebPart.Controllers
{
    public class ExamController : Controller
    {
        Uri basedaddress = new Uri("http://localhost:9748/api");
        private readonly HttpClient _httpClient;
        public ExamController()
        {
            _httpClient = new HttpClient();
            _httpClient.BaseAddress = basedaddress;
        }
        public IActionResult Index()
        {
            List<User> userList = new List<User>();
            HttpResponseMessage response = _httpClient.GetAsync(_httpClient.BaseAddress + "/AdminFunction/ViewUsers").Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                userList = JsonConvert.DeserializeObject<List<User>>(data);
            }
            return View(userList);
        }
        public IActionResult CreateExam()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> CreateExam(Exam exam)
        {
            HttpResponseMessage response = await _httpClient.PostAsJsonAsync($"{basedaddress}/Exam/CreateExam", exam);
            if (response.IsSuccessStatusCode)
            {
                return View("Index");
            }
            else
            {
                return BadRequest("Check once again");
            }
        }
        public IActionResult UpdateExam()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> UpdateExam(Exam exam)
        {
            HttpResponseMessage response = await _httpClient.PostAsJsonAsync($"{basedaddress}/Exam/UpdateExam", exam);
            if (response.IsSuccessStatusCode)
            {
                return View("Index");
            }
            else
            {
                return BadRequest("Check once again");
            }
        }
        [HttpPost]
        public async Task<IActionResult> DeleteExam(Exam exam)
        {
            HttpResponseMessage response = await _httpClient.PostAsJsonAsync($"{basedaddress}/Exam/DeleteExam", exam);
            if (response.IsSuccessStatusCode)
            {
                return View("Index");
            }
            else
            {
                return BadRequest("Check once again");
            }
        }
    }
}
